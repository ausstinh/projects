

<div class="form-container">
<h2>Make A Post</h2>
<p>Fill out all of the fields and submit</p>
<form action="processAddItem.php">
    Post Title:<input type="text" name="PostTitle"></input><br>
    Post Information:<textarea rows="5" cols="50" name="PostInformation"></textarea><br>
    <button type="submit">Add</button>
</form>
</div>
