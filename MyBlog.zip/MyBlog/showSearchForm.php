<
 
 <div class="form-container">

<h2>Search for a Post</h2>
<p>Fill out any of these fields and search</p>
<form action="searchPost.php">
Post Title:<input type="text" name="postName"></input><br>
Post Information:<input type="text" name="postinformation"></input><br>

<button type="submit">Search</button>
</form>
</div>

