package model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class BusinessContact extends BaseContact{
	//Business Contact constructs. Creating the Business Contact properties
	private String opening;
	private String closing;
	private Boolean[] daysOfWeekOpen;
	private String url;
	
	public BusinessContact(String name, String street, String city, String state, String photo, String zip,
			String country, String phoneNumber, String email, String opening, String closing, Boolean[] daysOfWeekOpen,
			String url) {
		super(name, street, city, state, photo, zip, country, phoneNumber, email);
		this.opening = opening;
		this.closing = closing;
		this.daysOfWeekOpen = daysOfWeekOpen;
		this.url = url;
	}

	public BusinessContact() {
		super("BusinessName", "Another street", "Middletown", "AZ", "82312", "United States", "923-324-4912", "BusinessStoreFront.jpg", "business@gmail.com");
		this.opening = "12:00 a.m.";
		this.closing = "12:00 p.m.";
		this.daysOfWeekOpen = new Boolean [] {false, true, true, true, true, true, false};
		this.url = "http://www.somewhere.com";
	}


	public String getOpening() {
		return opening;
	}

	public void setOpening(String opening) {
		this.opening = opening;
	}

	public String getClosing() {
		return closing;
	}
	
	public void setClosing(String closing) {
		this.closing = closing;
	}
	
	public Boolean[] getDaysOfWeekOpen() {
		return daysOfWeekOpen;
	}

	public void setDaysOfWeekOpen(Boolean[] daysOfWeekOpen) {
		this.daysOfWeekOpen = daysOfWeekOpen;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}


	@Override
	public int compareTo(BaseContact o) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String openURLPage() {
		System.out.println("Chrome is now opening to " + this.url);
		return this.url;
		
	}

	public String toString() {
	       String Return = "----------Business Contact--------------\n"
	                          + "Business Name " + this.name + "\n" 
	                          + "Street = " + super.street + "\n"
	                          + "City = " + super.city + " State = " + super.state + "\n"
	                          + "Zip Code = " + super.zip + "\n"
	                          + "Country = " + super.country + "\n"
	                          + "Phone #: = " + super.phoneNumber + "\n"
	                          + "Email = " + super.email + "\n"
	                          + "Business Opening Hours = " + this.opening + "\n"
	                          + "Business Closing Hours = " + this.closing + "\n"
	                          + "Website = " + this.url;

	       return Return;
	}

}
