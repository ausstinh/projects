package model;

public abstract class BaseContact implements Comparable<BaseContact> {
	//Base Contact construction. Creating the properties of any contact. 
	protected String name;
	protected String street;
	protected String city;
	protected String state;
	protected String photo;
	protected String zip;
	protected String country;
	protected String phoneNumber;
	protected String email;
	
	
	
	public BaseContact(String name, String street, String city, String state, String photo, String zip, String country,
			String phoneNumber, String email) {
		super();
		this.name = name;
		this.street = street;
		this.city = city;
		this.state = state;
		this.photo = photo;
		this.zip = zip;
		this.country = country;
		this.phoneNumber = phoneNumber;
		this.email = email;
		
	}

	public BaseContact() {
		this.name = "Austin Harvey";
		this.street = "514 Broad St";
		this.city = "Menasha";
		this.state = "Wisconsin";
		this.photo = "mypicture.jpg";
		this.zip = "54952";
		this.country = "United States";
		this.phoneNumber = "920-509-10530";
		this.email = "austinharvey49@gmail.com";
				
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


	public String getZip() {
		return zip;
	}


	public void setZip(String zip) {
		this.zip = zip;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}

	public void callContact(String contact) {
		System.out.println("Calling..." + contact);
		
	}

	public void nagivateToContact(String contact) {
		System.out.println("Navigating..." + contact);
		
	}

	public void emailToContact(String contact) {
		System.out.println("Emailing..." + contact);
	}

	public void textContact(String contact) {
		System.out.println("Texting..." + contact);
		
	}

	@Override
	public String toString() {
		return "BaseContact name=" + name + "\n"
				+ ", street=" + street +"\n"
				+ ", city=" + city + "\n"
				+ "," + " state=" + state + "\n"
				+ ", photo="+ photo + "\n"
				+ ", zip=" + zip + "\n"
				+ ", country=" + country + "\n" 
				+ ", phoneNumber=" + phoneNumber + "\n" 
				+ ", email=" + email + "\n";
	}
	
	
	
	
	
}


