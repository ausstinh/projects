package model;

public class PersonContact extends BaseContact{
	//Person Contact construction. Creating the properties for the Person Contact
	private String dateOfBirth;
	private String description;
	private String lastName;
	private String firstName;
	
	public PersonContact(String name, String firstName, String lastName, String street, String city, String state, String photo, String zip,
			String country, String phoneNumber, String email, String dateOfBirth, String description) {
		super(name, street, city, state, photo, zip, country, phoneNumber, email);
		this.dateOfBirth = dateOfBirth;
		this.description = description;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public PersonContact() {
		super("Austin Harvey", "514 Broad St.", "Menasha", "WI", "54952", "United States", "920-509-1053", "mypicture.jpg", "austinharvey49@gmail.com");
		this.dateOfBirth = "July 9th, 1998";
		this.description = "Cool, Funny, and Smart";
		this.firstName = "Austin";
		this.lastName = "Harvey";
	
	}


	public String getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int compareTo(BaseContact o) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String toString() {
	       String Return = "----------Person Contact--------------\n"
	                          + "Person Name =  " + this.name + "\n" 
	                          + "First Name = " + this.firstName + "\n"
	                          + "Last Name = " + this.lastName + "\n"
	                          + "Street = " + super.street + "\n"
	                          + "City = " + super.city + "\n"
	                          + "State = " + super.state + "\n"
	                          + "Zip Code = " + super.zip + "\n"
	                          + "Country = " + super.country + "\n"
	                          + "Phone # = " + super.phoneNumber + "\n"
	                          + "Email = " + super.email + "\n"
	                          + "Photo = " + super.photo + "\n"
	                          + "Date of Birth = " + this.dateOfBirth + "\n"
	                          + "Description = " + this.description + "\n";
	                          

	       return Return;
	}

}
