package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;




public class AddressBook {

	//main data storage structure for the entire application
	private ArrayList<BaseContact> theList;
	private String firstName;
	private String lastName;
	
	public AddressBook(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	//default constructor creates an empty list of type BaseContact
	public AddressBook()
	{
		this.theList = new ArrayList<BaseContact>();
	}
	
	//add one person/business contact to the list
	public <T extends BaseContact> void addOne(T contact) {
		this.theList.add(contact);
	}
	//remove a contact from the main list. Return true for success, false for failure
	public <T extends BaseContact> boolean deleteOne(T contact) {
		if(this.theList.contains(contact)) {
			this.theList.remove(contact);
			return true;
		}
		else {
			return false;
		}
	}
	
	public int compareTo(AddressBook contact) {
		
		 if ( this.lastName == contact.lastName) {
			 return this.firstName.compareTo(contact.firstName);
		 }
		 return (this.lastName.compareTo(contact.lastName));
		
		 
	
}
	
	public List<BaseContact> searchForName(String search) {
		List<BaseContact> l = new ArrayList<BaseContact>();
		
		// loop through all constants.
		
		for(int i =0; i < theList.size(); i++) {
			if(theList.get(i).getName().contains(search)) {
				l.add(theList.get(i));
			}
		}
		
		return l;
	}
	
	public List<BaseContact> searchForNumber(String search) {
		List<BaseContact> l = new ArrayList<BaseContact>();
		
		// loop through all contacts.
		
		for(int i =0; i < theList.size(); i++) {
			if(theList.get(i).getPhoneNumber().contains(search)) {
				l.add(theList.get(i));
			}
		}
		
		return l;
	}
	public List<BaseContact> searchForCity(String search) {
		List<BaseContact> l = new ArrayList<BaseContact>();
		
		// loop through all contacts.
		
		for(int i =0; i < theList.size(); i++) {
			if(theList.get(i).getCity().contains(search)) {
				l.add(theList.get(i));
			}
		}
		
		return l;
	}
	
	public List<BaseContact> getTheList() {
		return theList;
	}

	public List<BaseContact> getBusinessList() {
		List<BaseContact> business = new ArrayList<BaseContact>();
		
		for(int i =0; i < theList.size(); i++) {
			if(theList.get(i).getClass() ==  BusinessContact.class ){
				business.add(theList.get(i));
			}
		}
	
		return business;
	}

	public List<BaseContact> getPersonList() {
		List<BaseContact> person = new ArrayList<BaseContact>();
		
		for(int i =0; i < theList.size(); i++) {
			if(theList.get(i).getClass() ==  PersonContact.class ) {
				person.add(theList.get(i));
			}
		}
	
		return person;
	}

	@Override
	public String toString() {
		return "AddressBook ContactList: "+ "\n" + theList + "\n";
				
	}
	
	
	
}
