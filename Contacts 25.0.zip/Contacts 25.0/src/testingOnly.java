import businessServices.BusinessService;
import model.BusinessContact;
import model.PersonContact;

public class testingOnly {

	public static void main(String[] args) throws Exception {
		System.out.println("Starting the test script");

		// BusinessService has "list" which is the main data storage structure for the
		// application.
		BusinessService bs = new BusinessService();
		
		//Add three persons to contact list
		PersonContact p1 = new PersonContact();
		System.out.println("====new Person object====");
		System.out.println("");
		System.out.println(p1.toString());
		System.out.println("");

		bs.list.addOne(p1);

		PersonContact p2 = new PersonContact("Jimmy Jones", "Jimmy", "Jones", "415 Spring Rd.", "Hudson", "AZ",
				 "Jimmupicture.jpg", "54932", "United States", "540-777-8592", "Jimmy@gmail.com", "August 12th, 2004",
				"Young, Hip, and Neat");

		System.out.println("====new Person object====");
		System.out.println("");
		System.out.println(p2.toString());
		System.out.println("");
		bs.list.addOne(p2);

		PersonContact p3 = new PersonContact("Sarah Edwards", "Sarah", "Edwards", "630 Harvard St.", "Winchester", "WA",
				"Sarahpicture.jpg", "96532", "United States", "567-103-6542", "Sarah@gmail.com", "September 15th, 1980",
				"Interesting, Smart, and Funny");
		
		System.out.println("====new Person object====");
		System.out.println("");
		System.out.println(p3.toString());
		System.out.println("");
		bs.list.addOne(p3);
		
		//show all person contact list
		System.out.println("====updated list of contacts====");
		System.out.println("");
		System.out.println(bs.list.toString());
		System.out.println("");

		// 2 - search
		System.out.println("Search for 'har'");
		System.out.println(bs.getList().searchForName("Har"));
		System.out.println("Search for '567-103-6542'");
		System.out.println(bs.getList().searchForNumber("6542"));
		System.out.println("Search for 'Hudson'");
		System.out.println(bs.getList().searchForCity("Hudson"));

		// 3 - delete
		bs.list.deleteOne(p1);

		// 4 - call, text, email, navigate contact
		System.out.println("");
		bs.list.getTheList().get(0).callContact("Austin");
		bs.list.getTheList().get(0).nagivateToContact("Austin");
		bs.list.getTheList().get(0).emailToContact("Austin");
		bs.list.getTheList().get(0).textContact("Austin");
		System.out.println("");
		
		//create business contact
		System.out.println("Adding a new Business Contact.");
		BusinessContact b = new BusinessContact();
		System.out.println("");
		System.out.println(b);
		System.out.println("");
		
		//add to business contact list
		bs.list.addOne(b);
		
		//show full list of contacts
		System.out.println(bs.list);

		BusinessContact b1 = (BusinessContact) bs.list.getBusinessList().get(0);
		// call the openURL method
		b1.openURLPage();
		System.out.println("");

		// delete
		bs.list.deleteOne(b);
		System.out.println(bs.list);
	}
}
