package businessServices;

import dataAccess.DataAccessService;
import dataAccess.FileIOService;
import model.AddressBook;

public class BusinessService {
	//holds the global variables and methods to persist data.
	//"list" is the main data storage structure for the entire application.

	public AddressBook list;
	
	public BusinessService(AddressBook list) {
		super();
		this.setList(list);
	}

	public BusinessService() {
		super();
		this.setList(new AddressBook());
	}
	
	public void saveAllLists() {
		//write all data to the file / database.
		DataAccessService das = new FileIOService();
		das.writeAllData(this);
	}
	
	public BusinessService loadAllLists() {
		//read data from file / database.
		DataAccessService das = new FileIOService();
		return das.readAllData();
	}
	
	public AddressBook getList() {
		return list;
	}

	public void setList(AddressBook list) {
		this.list = list;
	}




}
