package dataAccess;

import businessServices.BusinessService;

public class DBAccessService implements DataAccessService{

	@Override
	public BusinessService readAllData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean writeAllData(BusinessService contactApp) {
		// TODO Auto-generated method stub
		return false;
	}

}
