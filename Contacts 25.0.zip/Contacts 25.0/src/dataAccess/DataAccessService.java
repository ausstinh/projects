package dataAccess;

import businessServices.BusinessService;

public interface DataAccessService {
	//read and save all the data on the app
	public BusinessService readAllData();
	boolean writeAllData(BusinessService contactApp);
}
